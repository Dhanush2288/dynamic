export const environment = {
  production: true,
  SERVER_BASE_URL: 'http://appservices.vetinstant.com:4000'
};
